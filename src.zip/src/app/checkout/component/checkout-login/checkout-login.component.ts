import { Component, inject } from '@angular/core';
import { CheckoutBannerComponent } from '../checkout-banner/checkout-banner.component';
import {
  FormGroup,
  FormBuilder,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import {  CommonModule } from '@angular/common';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-checkout-login',
  standalone: true,
  imports: [CheckoutBannerComponent, ReactiveFormsModule,CommonModule],
  templateUrl: './checkout-login.component.html',
  styleUrl: './checkout-login.component.css',
})
export class CheckoutLoginComponent {
  bannerContent: any = {
    title: 'Check-out',
    subtitle: 'Haz tu salida del hotel de la forma más sencilla',
  };

  private _fb = inject(FormBuilder);
  
  endpointSomulationService = inject(ApiService)
  data$: Observable<any> = this.endpointSomulationService.fetchTranslations()
  // location$: Observable<any> = this.endpointSomulationService.getLocation()
  // data: any;
  // private readonly traducciones = inject(ApiService)

  public hotelForm = this._fb.nonNullable.group({
    room: [
      '',
      [
        Validators.required,
        Validators.minLength(3),
        Validators.pattern('^[0-9]*$'),
      ],
    ],
    password: ['', [Validators.required, Validators.minLength(3)]],
  });
  // }
  // ngOnInit(): void {
  //   // Suscribirse al observable para obtener datos
  //   this.data$.subscribe((response) => {
  //     this.data = response;
  //     console.log('data--', this.data["title.checkout"]);
  //   });
  // }
  ngOnInit(): void {
    // Suscribirse al observable para obtener los datos
    this.data$.subscribe((data: any) => {
      // Actualizar el subtitle con el valor correspondiente
      this.bannerContent.subtitle = data["title.checkout"] ; // Asigna el valor o una cadena vacía
      this.bannerContent.title = data["general.checkout"]; // Asigna el valor o una cadena vacía
    });
  }
  onSubmit(): void {
    const name = this.hotelForm.controls.room.value;
    console.log(name);
    console.log('valid--', this.hotelForm.controls.room.valid);
    console.log('invalid--', this.hotelForm.controls.room.errors);
    console.log(
      'pruebaaa ---- ',
      this.hotelForm.controls.room.hasError('required')
    );
    console.log(
      'pruebaaa ---- ',
      this.hotelForm.controls.password.hasError('required')
    );
    // }
    if (this.hotelForm.valid) {
      console.log(this.hotelForm.valid);
    }
  }


  // this.traducciones.getallTranslate().subscribe((data: any) => {
  //   this.bannerContent.subtitle = data?.title?.checkout || '';
  // });
}
