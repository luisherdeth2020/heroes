import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-checkout-banner',
  standalone: true,
  imports: [],
  templateUrl: './checkout-banner.component.html',
  styleUrl: './checkout-banner.component.scss',
})
export class CheckoutBannerComponent {
  @Input() values: { title: string; subtitle: string } = {
    title: '',
    subtitle: '',
  };
}
