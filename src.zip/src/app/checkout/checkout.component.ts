import { Component, OnInit } from '@angular/core';
import { CheckoutLoginComponent } from './component/checkout-login/checkout-login.component';
import { Title } from "@angular/platform-browser";


@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CheckoutLoginComponent],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css',
})
export class CheckoutComponent implements OnInit {
  constructor(private titleService: Title) {}

  ngOnInit() {
    this.titleService.setTitle("Checkout");
  }
}
