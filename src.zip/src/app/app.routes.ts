import { Routes } from '@angular/router';
import { CheckoutComponent } from './checkout/checkout.component';
import { CheckoutLoginComponent } from './checkout/component/checkout-login/checkout-login.component';

export const routes: Routes = [
  {
    path: '',
    component: CheckoutComponent,
    children: [
      {
        path: 'login',
        component: CheckoutLoginComponent,
        pathMatch: 'full',
      },
      { path: '**', redirectTo: 'check-out' },
    ],
  },
];
