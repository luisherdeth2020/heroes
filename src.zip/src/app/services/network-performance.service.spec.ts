import { TestBed } from '@angular/core/testing';

import { NetworkPerformanceService } from './network-performance.service';

describe('NetworkPerformanceService', () => {
  let service: NetworkPerformanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NetworkPerformanceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
