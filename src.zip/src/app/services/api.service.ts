import { inject, Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, Observable, switchMap } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private _http = inject(HttpClient);
  private overrideLanguage: string = '';

  getLocation(): Observable<any> {
    return this._http
      .get<any>(
        'https://riucom-inci.riu.net/json-utils!user.action?formato=json'
      )
      .pipe(
        map((res: any) => {
          console.log('rees--', res.language);
          this.overrideLanguage = res.language; // Guardar el idioma
          return this.overrideLanguage;
        }),
        catchError((error: any) => {
          console.error('Error fetching translations:', error);
          throw error; // O puedes manejar el error de otra forma
        })
      );
  }

  getallTranslate(language: string): Observable<any> {
    return this._http
      .get<any>(
        `https://riucom-inci.riu.net/cms!getAllEtiquetasByMultiplesPageEtiquetaKeyId.action?formato=json&keyIds=checkin.home,checkin.login,Contacto,home,top-bar,footer-riu,legal,menu.header,checkin.habitaciones,checkin.datos.huesped,checkin.confirmado,reservas.rc&language=${language}&production=true`
      )
      .pipe(
        map((res: any) => {
          let etiquetas: { [key: string]: string } = {};
          for (let eti of res.etiquetas) {
            etiquetas[eti['keyId']] = eti.content;
          }
          return etiquetas;
        }),
        catchError((error: any) => {
          console.error('Error fetching translations:', error);
          throw error; // O puedes manejar el error de otra forma
        })
      );
  }

  fetchTranslations(): Observable<any> {
    return this.getLocation().pipe(
      switchMap((language) => this.getallTranslate(language))
    );
  }
}
// cacheKey : string

// constructor(private _cache: NetworkPerformanceService) { }

// setInfoUsuario() {
//   var d = new Date();
//   var urlURI = environment.urlActionDev + "/json-utils!user.action?formato=json";
//   let httpHeaders = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
//   let options = {headers: httpHeaders, userCredentials: true};
//   this.cacheKey = urlURI
//   const expire = new Date()
//   expire.setMinutes(expire.getMinutes()+3)

//   return this._cache.get(urlURI, options,false,expire).toPromise().then((response : any) => {
//     response.language =  response.language == 'pl' ? 'en' : response.language;
//     if (this.overrideLanguage) response.language = this.overrideLanguage;
//     if (this.datosSessionRiu?.language!=response.language) {
//       this.emitConfig(response.language);
//       this.cambiarIdiomaBack(response.language)
//     }
//     this.datosSessionRiu = response;
//     this.country = this.datosSessionRiu.country;
//     this.datosSessionRiuEmitter.next(response);
//     this.datosSessionRiuBSubject.next(response);
//     if (window.location.href.indexOf('riupro') > 0) {
//       if(this.datosSessionRiu.agency && this.datosSessionRiu.agency.markets){
//        this.datosSessionRiu.agency.marketDedault = this.datosSessionRiu.agency.markets[0];
//        setTimeout(()=>{
//            this.datosSessionRiu.agency.markets = this.datosSessionRiu.agency.markets.sort((a,b)=>{
//          if(a.value > b.value)
//            return 1;
//          else
//            return -1
//          });
//        });
//       }
//       this.datosSessionRiu.PATH = 'riupro';

//       if(this.datosSessionRiu.agency)
//       if(!this.datosSessionRPC && this.datosLogin && this.datosLogin.usr && this.datosSessionRiu.agency && this.datosSessionRiu.agency.profile && (this.datosSessionRiu.agency.profile == 'RPC' || this.datosSessionRiu.agency.profile == 'RA-RPC')){
//         if(!this.swiTryLoginRpc){
//           this.setLoginRPC(this.datosLogin.usr, this.datosLogin.pwd);
//           this.swiTryLoginRpc = true;
//         }
//       }else if(this.datosSessionRiu.agency && (this.datosSessionRiu.agency.profile == 'RPC' || this.datosSessionRiu.agency.profile == 'RA-RPC')){
//         this.getInfoCB(['datosSessionRPC']).then((res: any) => {
//           this.datosSessionRPC = res && res.datosSessionRPC?JSON.parse(res.datosSessionRPC.v):null;
//         })

//         this.resetSessionRpc();

//       }

//       if (this.datosSessionRiu.type == "DIRECTO") {
//         this.swiSessionPerdida = true;
//         for (var i = 0; i < environment.rutasPublicas.length; i++) {
//           if (window.location.href.indexOf(environment.rutasPublicas[i]) >= 0) {
//             this.swiSessionPerdida = false;
//             break;
//           }
//         }
//       }
//       else
//         this.swiSessionPerdida = false;
//     }
//   });

// }
