// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { BehaviorSubject, Subject } from 'rxjs';
// import { fromPromise } from 'rxjs/internal-compatibility';

// @Injectable({
//   providedIn: 'root'
// })
// export class NetworkPerformanceService {

//   constructor(private http: HttpClient) { }

//   cache: { [url: string]: any } = {}

//   erase() {
//     this.cache = {}
//   }
//   delete(url) {
//     const urlClean = url.replace(/^\/|\/$/g, '');
//     return delete this.cache[urlClean]
//   }

//   fetch(url: string) {
//     return this.get(url, null, true)
//   }

//   get(url: string, headers?: any, useFetch?: boolean, expire?: Date) {
//     const urlClean = url.replace(/^\/|\/$/g, '');
//     let cache = this.cache[urlClean]
//     if (cache?.expire?.getTime() < Date.now()) {
//       cache = null
//     }
//     if (!cache || cache.error) {
//       const s = new Subject();
//       cache = this.cache[urlClean] = {
//         isDone: false,
//         error: false,
//         data: null,
//         observable: s,
//         expire
//       }
//       let observable = null
//       if (useFetch == true) {
//         if (headers != null) observable = fromPromise(fetch(url, { headers }).then(t => t.json()));
//         else observable = fromPromise(fetch(url).then(t => t.json()));
//       } else {
//         observable = this.http.get(url, headers)
//       }
//       observable.subscribe({
//         next(data) {
//           cache.data = data
//           cache.isDone = true
//           s.next(data)
//           s.complete()
//         },
//         error(err) {
//           console.error("error cache", err)
//           cache.error = true
//           s.error(err)
//         },
//       })
//       this.cache[urlClean] = cache

//       return cache.observable
//     } else {
//       if (cache.isDone) return new BehaviorSubject(cache.data)
//       else return cache.observable
//     }
//   }
// }
