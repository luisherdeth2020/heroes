export const environment = {

  production: false,
  entorno: 'des',
  urlActionDev: 'angularActions/',
  mapbox: {
    accessToken: 'pk.eyJ1IjoiaWxhY29zdGEiLCJhIjoiY2o5cGVnNXBzNWt5MDMzcXFldXZsMndpZSJ9.oRZQbW2R_5tZ7o6C_GCAEg'
  },

  /**** RIUCOM ****/

  idiomasRiucom: [{key:'de', value:'Deutsch'},{key:'es', value:'Español'},{key:'en', value:'English'},{key:'pl', value:'Polski'},{key:'fr', value:'Français'},{key:'it', value:'Italiano'},{key:'nl', value:'Nederlands'},{key:'pt', value:'Português'},{key:'ru', value:'Русский'},{key:'zh', value:'中文'}],
  urlAssetsGen: '',
  enlacesTopBar: {
    'enlace-destinos': '#idioma#/hotel',
    'enlace-riuclass': 'riu-class/?lang=#idioma#',
    'enlace-riuparty': 'riu-party/index.jsp',
    //'enlace-hotelVuelo': ''
  },
  mapBoxToken: 'pk.eyJ1IjoiaWxhY29zdGEiLCJhIjoiY2o5cGVnNXBzNWt5MDMzcXFldXZsMndpZSJ9.oRZQbW2R_5tZ7o6C_GCAEg',

  /**** FIN RIUCOM ****/

  /**** RIUAGENTS ****/
  urlPath: '/'+window.location.pathname.substr(1,3)+ 'riu-agents/angular-riu-agents/src/app/riuagents/components',
  urlAssetsAgents : '',
  tiposCabecera: {
    home: ['riupro'],
    publica:['registro', 'contacto', 'faqs'],
    privada:['my-agents/dashboard', 'my-agents/profile','my-agents/disponibilidad','my-agents/offers', 'my-agents/reservas']
  },
  rutasPublicas: ['registro', 'contacto', 'faqs', 'riupro'],
  urlLoginRpc: 'urlLoginRpcActions',
  numofertasRand: 3,
  /**** FIN RIUAGENTS ****/



  /****DUMIES***/

    dumOptDes: {
      'nuevo_deseo_HAB_E' : [{ 'desc' : 'Separate beds', 'value':'HA1'},{ 'desc' : 'King Size bed', 'value':'HA2'},{ 'desc' : 'rooms together', 'value':'HA3'}]

      ,'nuevo_deseo_UBI_E' :[{ 'desc' : 'High floor', 'value':'UB1'},{ 'desc' : 'Ground floor', 'value':'UB2'}]

      ,'nuevo_deseo_OTR_E':[{ 'desc' : 'Honeymoon', 'value':'OT1'},{ 'desc' : 'Anniversary', 'value':'OT2'}]
    }
    /*************/
}
